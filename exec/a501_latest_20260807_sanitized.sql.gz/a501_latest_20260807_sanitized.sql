-- MySQL dump 10.13  Distrib 8.4.11, for Linux (x86_64)
--
-- Host: localhost    Database: a501
-- ------------------------------------------------------
-- Server version	8.4.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `BATCH_JOB_EXECUTION`
--

DROP TABLE IF EXISTS `BATCH_JOB_EXECUTION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BATCH_JOB_EXECUTION` (
  `JOB_EXECUTION_ID` bigint NOT NULL,
  `VERSION` bigint DEFAULT NULL,
  `JOB_INSTANCE_ID` bigint NOT NULL,
  `CREATE_TIME` datetime(6) NOT NULL,
  `START_TIME` datetime(6) DEFAULT NULL,
  `END_TIME` datetime(6) DEFAULT NULL,
  `STATUS` varchar(10) DEFAULT NULL,
  `EXIT_CODE` varchar(2500) DEFAULT NULL,
  `EXIT_MESSAGE` varchar(2500) DEFAULT NULL,
  `LAST_UPDATED` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`JOB_EXECUTION_ID`),
  KEY `JOB_INST_EXEC_FK` (`JOB_INSTANCE_ID`),
  CONSTRAINT `JOB_INST_EXEC_FK` FOREIGN KEY (`JOB_INSTANCE_ID`) REFERENCES `BATCH_JOB_INSTANCE` (`JOB_INSTANCE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BATCH_JOB_EXECUTION`
--

LOCK TABLES `BATCH_JOB_EXECUTION` WRITE;
/*!40000 ALTER TABLE `BATCH_JOB_EXECUTION` DISABLE KEYS */;
/*!40000 ALTER TABLE `BATCH_JOB_EXECUTION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BATCH_JOB_EXECUTION_CONTEXT`
--

DROP TABLE IF EXISTS `BATCH_JOB_EXECUTION_CONTEXT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BATCH_JOB_EXECUTION_CONTEXT` (
  `JOB_EXECUTION_ID` bigint NOT NULL,
  `SHORT_CONTEXT` varchar(2500) NOT NULL,
  `SERIALIZED_CONTEXT` text,
  PRIMARY KEY (`JOB_EXECUTION_ID`),
  CONSTRAINT `JOB_EXEC_CTX_FK` FOREIGN KEY (`JOB_EXECUTION_ID`) REFERENCES `BATCH_JOB_EXECUTION` (`JOB_EXECUTION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BATCH_JOB_EXECUTION_CONTEXT`
--

LOCK TABLES `BATCH_JOB_EXECUTION_CONTEXT` WRITE;
/*!40000 ALTER TABLE `BATCH_JOB_EXECUTION_CONTEXT` DISABLE KEYS */;
/*!40000 ALTER TABLE `BATCH_JOB_EXECUTION_CONTEXT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BATCH_JOB_EXECUTION_PARAMS`
--

DROP TABLE IF EXISTS `BATCH_JOB_EXECUTION_PARAMS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BATCH_JOB_EXECUTION_PARAMS` (
  `JOB_EXECUTION_ID` bigint NOT NULL,
  `PARAMETER_NAME` varchar(100) NOT NULL,
  `PARAMETER_TYPE` varchar(100) NOT NULL,
  `PARAMETER_VALUE` varchar(2500) DEFAULT NULL,
  `IDENTIFYING` char(1) NOT NULL,
  KEY `JOB_EXEC_PARAMS_FK` (`JOB_EXECUTION_ID`),
  CONSTRAINT `JOB_EXEC_PARAMS_FK` FOREIGN KEY (`JOB_EXECUTION_ID`) REFERENCES `BATCH_JOB_EXECUTION` (`JOB_EXECUTION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BATCH_JOB_EXECUTION_PARAMS`
--

LOCK TABLES `BATCH_JOB_EXECUTION_PARAMS` WRITE;
/*!40000 ALTER TABLE `BATCH_JOB_EXECUTION_PARAMS` DISABLE KEYS */;
/*!40000 ALTER TABLE `BATCH_JOB_EXECUTION_PARAMS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BATCH_JOB_EXECUTION_SEQ`
--

DROP TABLE IF EXISTS `BATCH_JOB_EXECUTION_SEQ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BATCH_JOB_EXECUTION_SEQ` (
  `ID` bigint NOT NULL,
  `UNIQUE_KEY` char(1) NOT NULL,
  UNIQUE KEY `BATCH_JOB_EXECUTION_SEQ_UN` (`UNIQUE_KEY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BATCH_JOB_EXECUTION_SEQ`
--

LOCK TABLES `BATCH_JOB_EXECUTION_SEQ` WRITE;
/*!40000 ALTER TABLE `BATCH_JOB_EXECUTION_SEQ` DISABLE KEYS */;
/*!40000 ALTER TABLE `BATCH_JOB_EXECUTION_SEQ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BATCH_JOB_INSTANCE`
--

DROP TABLE IF EXISTS `BATCH_JOB_INSTANCE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BATCH_JOB_INSTANCE` (
  `JOB_INSTANCE_ID` bigint NOT NULL,
  `VERSION` bigint DEFAULT NULL,
  `JOB_NAME` varchar(100) NOT NULL,
  `JOB_KEY` varchar(32) NOT NULL,
  PRIMARY KEY (`JOB_INSTANCE_ID`),
  UNIQUE KEY `JOB_INST_UN` (`JOB_NAME`,`JOB_KEY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BATCH_JOB_INSTANCE`
--

LOCK TABLES `BATCH_JOB_INSTANCE` WRITE;
/*!40000 ALTER TABLE `BATCH_JOB_INSTANCE` DISABLE KEYS */;
/*!40000 ALTER TABLE `BATCH_JOB_INSTANCE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BATCH_JOB_INSTANCE_SEQ`
--

DROP TABLE IF EXISTS `BATCH_JOB_INSTANCE_SEQ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BATCH_JOB_INSTANCE_SEQ` (
  `ID` bigint NOT NULL,
  `UNIQUE_KEY` char(1) NOT NULL,
  UNIQUE KEY `BATCH_JOB_INSTANCE_SEQ_UN` (`UNIQUE_KEY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BATCH_JOB_INSTANCE_SEQ`
--

LOCK TABLES `BATCH_JOB_INSTANCE_SEQ` WRITE;
/*!40000 ALTER TABLE `BATCH_JOB_INSTANCE_SEQ` DISABLE KEYS */;
/*!40000 ALTER TABLE `BATCH_JOB_INSTANCE_SEQ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BATCH_STEP_EXECUTION`
--

DROP TABLE IF EXISTS `BATCH_STEP_EXECUTION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BATCH_STEP_EXECUTION` (
  `STEP_EXECUTION_ID` bigint NOT NULL,
  `VERSION` bigint NOT NULL,
  `STEP_NAME` varchar(100) NOT NULL,
  `JOB_EXECUTION_ID` bigint NOT NULL,
  `CREATE_TIME` datetime(6) NOT NULL,
  `START_TIME` datetime(6) DEFAULT NULL,
  `END_TIME` datetime(6) DEFAULT NULL,
  `STATUS` varchar(10) DEFAULT NULL,
  `COMMIT_COUNT` bigint DEFAULT NULL,
  `READ_COUNT` bigint DEFAULT NULL,
  `FILTER_COUNT` bigint DEFAULT NULL,
  `WRITE_COUNT` bigint DEFAULT NULL,
  `READ_SKIP_COUNT` bigint DEFAULT NULL,
  `WRITE_SKIP_COUNT` bigint DEFAULT NULL,
  `PROCESS_SKIP_COUNT` bigint DEFAULT NULL,
  `ROLLBACK_COUNT` bigint DEFAULT NULL,
  `EXIT_CODE` varchar(2500) DEFAULT NULL,
  `EXIT_MESSAGE` varchar(2500) DEFAULT NULL,
  `LAST_UPDATED` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`STEP_EXECUTION_ID`),
  KEY `JOB_EXEC_STEP_FK` (`JOB_EXECUTION_ID`),
  CONSTRAINT `JOB_EXEC_STEP_FK` FOREIGN KEY (`JOB_EXECUTION_ID`) REFERENCES `BATCH_JOB_EXECUTION` (`JOB_EXECUTION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BATCH_STEP_EXECUTION`
--

LOCK TABLES `BATCH_STEP_EXECUTION` WRITE;
/*!40000 ALTER TABLE `BATCH_STEP_EXECUTION` DISABLE KEYS */;
/*!40000 ALTER TABLE `BATCH_STEP_EXECUTION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BATCH_STEP_EXECUTION_CONTEXT`
--

DROP TABLE IF EXISTS `BATCH_STEP_EXECUTION_CONTEXT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BATCH_STEP_EXECUTION_CONTEXT` (
  `STEP_EXECUTION_ID` bigint NOT NULL,
  `SHORT_CONTEXT` varchar(2500) NOT NULL,
  `SERIALIZED_CONTEXT` text,
  PRIMARY KEY (`STEP_EXECUTION_ID`),
  CONSTRAINT `STEP_EXEC_CTX_FK` FOREIGN KEY (`STEP_EXECUTION_ID`) REFERENCES `BATCH_STEP_EXECUTION` (`STEP_EXECUTION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BATCH_STEP_EXECUTION_CONTEXT`
--

LOCK TABLES `BATCH_STEP_EXECUTION_CONTEXT` WRITE;
/*!40000 ALTER TABLE `BATCH_STEP_EXECUTION_CONTEXT` DISABLE KEYS */;
/*!40000 ALTER TABLE `BATCH_STEP_EXECUTION_CONTEXT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BATCH_STEP_EXECUTION_SEQ`
--

DROP TABLE IF EXISTS `BATCH_STEP_EXECUTION_SEQ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BATCH_STEP_EXECUTION_SEQ` (
  `ID` bigint NOT NULL,
  `UNIQUE_KEY` char(1) NOT NULL,
  UNIQUE KEY `BATCH_STEP_EXECUTION_SEQ_UN` (`UNIQUE_KEY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BATCH_STEP_EXECUTION_SEQ`
--

LOCK TABLES `BATCH_STEP_EXECUTION_SEQ` WRITE;
/*!40000 ALTER TABLE `BATCH_STEP_EXECUTION_SEQ` DISABLE KEYS */;
/*!40000 ALTER TABLE `BATCH_STEP_EXECUTION_SEQ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_report_generation_audit`
--

DROP TABLE IF EXISTS `admin_report_generation_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_report_generation_audit` (
  `audit_id` bigint NOT NULL AUTO_INCREMENT,
  `admin_parent_id` bigint NOT NULL,
  `child_id` bigint NOT NULL,
  `report_id` bigint NOT NULL,
  `report_date` date NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`audit_id`),
  KEY `idx_admin_report_audit_admin_created` (`admin_parent_id`,`created_at`),
  KEY `idx_admin_report_audit_child_date` (`child_id`,`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_report_generation_audit`
--

LOCK TABLES `admin_report_generation_audit` WRITE;
/*!40000 ALTER TABLE `admin_report_generation_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_report_generation_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `card_round`
--

DROP TABLE IF EXISTS `card_round`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `card_round` (
  `card_round_id` binary(16) NOT NULL,
  `game_session_id` binary(16) NOT NULL,
  `round_no` int NOT NULL,
  `status` varchar(20) NOT NULL,
  `comparison_count` int NOT NULL,
  `wrong_count` int NOT NULL,
  `final_grade` varchar(20) DEFAULT NULL,
  `solve_time_ms` bigint DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`card_round_id`),
  UNIQUE KEY `uk_card_round_session_round` (`game_session_id`,`round_no`),
  KEY `idx_card_round_game_session` (`game_session_id`),
  CONSTRAINT `fk_card_round_game_session` FOREIGN KEY (`game_session_id`) REFERENCES `game_session` (`game_session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `card_round`
--

LOCK TABLES `card_round` WRITE;
/*!40000 ALTER TABLE `card_round` DISABLE KEYS */;
/*!40000 ALTER TABLE `card_round` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `child`
--

DROP TABLE IF EXISTS `child`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `child` (
  `child_id` bigint NOT NULL AUTO_INCREMENT,
  `parent_id` bigint NOT NULL,
  `name` varchar(15) NOT NULL,
  `profile_image_key` varchar(512) NOT NULL DEFAULT 'profile-presets/child-avatar',
  `profile_image_num` int NOT NULL DEFAULT '1',
  `deleted_at` datetime(6) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`child_id`),
  KEY `idx_child_parent_active` (`parent_id`,`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `child`
--

LOCK TABLES `child` WRITE;
/*!40000 ALTER TABLE `child` DISABLE KEYS */;
/*!40000 ALTER TABLE `child` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `child_diary`
--

DROP TABLE IF EXISTS `child_diary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `child_diary` (
  `child_diary_id` bigint NOT NULL AUTO_INCREMENT,
  `child_id` bigint NOT NULL,
  `conversation_id` varchar(40) NOT NULL,
  `diary_date` date NOT NULL,
  `title` varchar(20) NOT NULL,
  `lines_json` text NOT NULL,
  `generation_method` varchar(20) NOT NULL,
  `model_version` varchar(100) DEFAULT NULL,
  `prompt_version` varchar(100) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`child_diary_id`),
  UNIQUE KEY `uk_child_diary_conversation` (`conversation_id`),
  KEY `idx_child_diary_child_date` (`child_id`,`diary_date`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `child_diary`
--

LOCK TABLES `child_diary` WRITE;
/*!40000 ALTER TABLE `child_diary` DISABLE KEYS */;
/*!40000 ALTER TABLE `child_diary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conversation_event`
--

DROP TABLE IF EXISTS `conversation_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `conversation_event` (
  `event_id` varchar(80) NOT NULL,
  `redis_record_id` varchar(80) NOT NULL,
  `conversation_id` varchar(40) NOT NULL,
  `realtime_session_id` varchar(80) NOT NULL,
  `session_epoch` int NOT NULL,
  `event_type` varchar(40) NOT NULL,
  `turn_id` varchar(40) DEFAULT NULL,
  `occurred_at` datetime(6) NOT NULL,
  `processed_at` datetime(6) NOT NULL,
  `processing_result` varchar(30) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`event_id`),
  UNIQUE KEY `uk_conversation_event_redis_record` (`redis_record_id`),
  KEY `idx_conversation_event_conversation_epoch` (`conversation_id`,`session_epoch`),
  KEY `idx_conversation_event_turn` (`conversation_id`,`turn_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conversation_event`
--

LOCK TABLES `conversation_event` WRITE;
/*!40000 ALTER TABLE `conversation_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `conversation_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conversation_event_failure`
--

DROP TABLE IF EXISTS `conversation_event_failure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `conversation_event_failure` (
  `conversation_event_failure_id` bigint NOT NULL AUTO_INCREMENT,
  `redis_record_id` varchar(80) NOT NULL,
  `event_id` varchar(80) DEFAULT NULL,
  `conversation_id` varchar(40) DEFAULT NULL,
  `event_type` varchar(40) DEFAULT NULL,
  `delivery_count` bigint NOT NULL,
  `failed_at` datetime(6) NOT NULL,
  `failure_reason` varchar(1000) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`conversation_event_failure_id`),
  UNIQUE KEY `uk_conversation_event_failure_record` (`redis_record_id`),
  KEY `idx_conversation_event_failure_record` (`redis_record_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conversation_event_failure`
--

LOCK TABLES `conversation_event_failure` WRITE;
/*!40000 ALTER TABLE `conversation_event_failure` DISABLE KEYS */;
/*!40000 ALTER TABLE `conversation_event_failure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conversation_game_session`
--

DROP TABLE IF EXISTS `conversation_game_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `conversation_game_session` (
  `conversation_game_session_id` varchar(80) NOT NULL,
  `conversation_id` varchar(40) NOT NULL,
  `game_session_id` binary(16) NOT NULL,
  `game_order` int NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`conversation_game_session_id`),
  UNIQUE KEY `uk_conversation_game_session` (`conversation_id`,`game_session_id`),
  UNIQUE KEY `uk_conversation_game_order` (`conversation_id`,`game_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conversation_game_session`
--

LOCK TABLES `conversation_game_session` WRITE;
/*!40000 ALTER TABLE `conversation_game_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `conversation_game_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conversation_session`
--

DROP TABLE IF EXISTS `conversation_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `conversation_session` (
  `conversation_id` varchar(40) NOT NULL,
  `child_id` bigint NOT NULL,
  `status` varchar(20) NOT NULL,
  `current_topic` varchar(20) NOT NULL,
  `question_count` int NOT NULL,
  `max_question_count` int NOT NULL,
  `current_session_epoch` int NOT NULL,
  `current_session_epoch_started_at` datetime(6) DEFAULT NULL,
  `started_at` datetime(6) DEFAULT NULL,
  `completed_at` datetime(6) DEFAULT NULL,
  `termination_reason` varchar(40) DEFAULT NULL,
  `version` bigint NOT NULL DEFAULT '0',
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`conversation_id`),
  KEY `idx_conversation_session_child_status` (`child_id`,`status`),
  KEY `idx_conversation_session_status_updated` (`status`,`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conversation_session`
--

LOCK TABLES `conversation_session` WRITE;
/*!40000 ALTER TABLE `conversation_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `conversation_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conversation_topic_state`
--

DROP TABLE IF EXISTS `conversation_topic_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `conversation_topic_state` (
  `conversation_topic_id` varchar(50) NOT NULL,
  `conversation_id` varchar(40) NOT NULL,
  `topic_type` varchar(20) NOT NULL,
  `topic_order` int NOT NULL,
  `status` varchar(20) NOT NULL,
  `question_count` int NOT NULL,
  `max_question_count` int NOT NULL,
  `slots_json` text NOT NULL,
  `context_json` text NOT NULL,
  `skipped_targets_json` text NOT NULL,
  `completion_reason` varchar(40) DEFAULT NULL,
  `started_at` datetime(6) DEFAULT NULL,
  `completed_at` datetime(6) DEFAULT NULL,
  `version` bigint NOT NULL DEFAULT '0',
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`conversation_topic_id`),
  UNIQUE KEY `uk_conversation_topic_type` (`conversation_id`,`topic_type`),
  UNIQUE KEY `uk_conversation_topic_order` (`conversation_id`,`topic_order`),
  KEY `idx_conversation_topic_status` (`conversation_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conversation_topic_state`
--

LOCK TABLES `conversation_topic_state` WRITE;
/*!40000 ALTER TABLE `conversation_topic_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `conversation_topic_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conversation_turn`
--

DROP TABLE IF EXISTS `conversation_turn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `conversation_turn` (
  `turn_id` varchar(40) NOT NULL,
  `conversation_id` varchar(40) NOT NULL,
  `turn_seq` int NOT NULL,
  `speaker` varchar(10) NOT NULL,
  `topic_type` varchar(20) NOT NULL,
  `content` text NOT NULL,
  `question_text` text,
  `question_target` varchar(30) DEFAULT NULL,
  `status` varchar(20) NOT NULL,
  `response_id` varchar(40) DEFAULT NULL,
  `stt_confidence` decimal(5,4) DEFAULT NULL,
  `started_at` datetime(6) DEFAULT NULL,
  `completed_at` datetime(6) DEFAULT NULL,
  `interrupted_at` datetime(6) DEFAULT NULL,
  `interruption_reason` varchar(40) DEFAULT NULL,
  `interruption_id` varchar(40) DEFAULT NULL,
  `version` bigint NOT NULL DEFAULT '0',
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`turn_id`),
  UNIQUE KEY `uk_conversation_turn_seq` (`conversation_id`,`turn_seq`),
  KEY `idx_conversation_turn_response_id` (`response_id`),
  KEY `idx_conversation_turn_interruption_id` (`interruption_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conversation_turn`
--

LOCK TABLES `conversation_turn` WRITE;
/*!40000 ALTER TABLE `conversation_turn` DISABLE KEYS */;
/*!40000 ALTER TABLE `conversation_turn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daily_report`
--

DROP TABLE IF EXISTS `daily_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daily_report` (
  `report_id` bigint NOT NULL AUTO_INCREMENT,
  `child_id` bigint NOT NULL,
  `report_date` date NOT NULL,
  `period_started_at` datetime(6) NOT NULL,
  `period_ended_at` datetime(6) NOT NULL,
  `generation_status` varchar(20) NOT NULL,
  `retry_count` int NOT NULL DEFAULT '0',
  `processing_started_at` datetime(6) DEFAULT NULL,
  `completed_at` datetime(6) DEFAULT NULL,
  `failed_at` datetime(6) DEFAULT NULL,
  `failure_reason` varchar(1000) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`report_id`),
  UNIQUE KEY `uk_daily_report_child_date` (`child_id`,`report_date`),
  KEY `idx_daily_report_status_processing` (`generation_status`,`processing_started_at`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_report`
--

LOCK TABLES `daily_report` WRITE;
/*!40000 ALTER TABLE `daily_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `daily_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyway_schema_history`
--

DROP TABLE IF EXISTS `flyway_schema_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flyway_schema_history` (
  `installed_rank` int NOT NULL,
  `version` varchar(50) DEFAULT NULL,
  `description` varchar(200) NOT NULL,
  `type` varchar(20) NOT NULL,
  `script` varchar(1000) NOT NULL,
  `checksum` int DEFAULT NULL,
  `installed_by` varchar(100) NOT NULL,
  `installed_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `execution_time` int NOT NULL,
  `success` tinyint(1) NOT NULL,
  PRIMARY KEY (`installed_rank`),
  KEY `flyway_schema_history_s_idx` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyway_schema_history`
--

LOCK TABLES `flyway_schema_history` WRITE;
/*!40000 ALTER TABLE `flyway_schema_history` DISABLE KEYS */;
INSERT INTO `flyway_schema_history` VALUES (1,'1','initial schema','SQL','V1__initial_schema.sql',-1532809160,'a501_app','2026-07-28 07:23:42',1512,1),(2,'2','conversation event tables','SQL','V2__conversation_event_tables.sql',880110539,'a501_app','2026-07-28 07:23:43',291,1),(3,'3','create game catalog','SQL','V3__create_game_catalog.sql',-954273822,'a501_app','2026-07-29 04:37:40',155,1),(4,'4','migrate profile image keys','SQL','V4__migrate_profile_image_keys.sql',1728974297,'a501_app','2026-07-29 04:52:18',236,1),(5,'5','restore profile image num rollback compatibility','SQL','V5__restore_profile_image_num_rollback_compatibility.sql',-355557906,'a501_app','2026-07-29 05:03:21',67,1),(6,'6','schedule report notifications','SQL','V6__schedule_report_notifications.sql',1167672673,'a501_app','2026-07-29 23:24:41',122,1),(7,'7','track unread report notifications','SQL','V7__track_unread_report_notifications.sql',1120632122,'a501_app','2026-07-30 02:24:31',73,1),(8,'8','persist conversation question target','SQL','V8__persist_conversation_question_target.sql',950778691,'a501_app','2026-07-31 00:21:52',34,1),(9,'9','persist conversation skipped targets','SQL','V9__persist_conversation_skipped_targets.sql',262030219,'a501_app','2026-07-31 00:21:52',118,1),(10,'10','expand parent report conversation summary','SQL','V10__expand_parent_report_conversation_summary.sql',604431793,'a501_app','2026-07-31 08:22:27',139,1),(11,'11','create recycling game result','SQL','V11__create_recycling_game_result.sql',-2091558506,'a501_app','2026-08-03 01:06:57',61,1),(12,'12','create word match game','SQL','V12__create_word_match_game.sql',1746203415,'a501_app','2026-08-03 01:06:57',95,1),(13,'13','store report notification time as minute','SQL','V13__store_report_notification_time_as_minute.sql',1640532022,'a501_app','2026-08-03 08:14:47',112,1),(14,'14','add parent role and admin report audit','SQL','V14__add_parent_role_and_admin_report_audit.sql',1848375392,'a501_app','2026-08-04 01:34:43',147,1);
/*!40000 ALTER TABLE `flyway_schema_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fruit_ninja_fruit_result`
--

DROP TABLE IF EXISTS `fruit_ninja_fruit_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fruit_ninja_fruit_result` (
  `fruit_result_id` binary(16) NOT NULL,
  `game_session_id` binary(16) NOT NULL,
  `fruit_code` varchar(40) NOT NULL,
  `generated_count` int NOT NULL,
  `sliced_count` int NOT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`fruit_result_id`),
  UNIQUE KEY `uk_fruit_ninja_fruit_session_code` (`game_session_id`,`fruit_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fruit_ninja_fruit_result`
--

LOCK TABLES `fruit_ninja_fruit_result` WRITE;
/*!40000 ALTER TABLE `fruit_ninja_fruit_result` DISABLE KEYS */;
/*!40000 ALTER TABLE `fruit_ninja_fruit_result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fruit_ninja_result`
--

DROP TABLE IF EXISTS `fruit_ninja_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fruit_ninja_result` (
  `game_session_id` binary(16) NOT NULL,
  `rules_version` varchar(40) NOT NULL,
  `total_fruit_count` int NOT NULL,
  `sliced_fruit_count` int NOT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`game_session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fruit_ninja_result`
--

LOCK TABLES `fruit_ninja_result` WRITE;
/*!40000 ALTER TABLE `fruit_ninja_result` DISABLE KEYS */;
/*!40000 ALTER TABLE `fruit_ninja_result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fruit_score_config`
--

DROP TABLE IF EXISTS `fruit_score_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fruit_score_config` (
  `rule_version_id` bigint NOT NULL,
  `fruit_type_id` bigint NOT NULL,
  `score` int NOT NULL,
  PRIMARY KEY (`rule_version_id`,`fruit_type_id`),
  KEY `fk_fruit_score_type` (`fruit_type_id`),
  CONSTRAINT `fk_fruit_score_rule` FOREIGN KEY (`rule_version_id`) REFERENCES `game_rule_version` (`rule_version_id`),
  CONSTRAINT `fk_fruit_score_type` FOREIGN KEY (`fruit_type_id`) REFERENCES `fruit_type` (`fruit_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fruit_score_config`
--

LOCK TABLES `fruit_score_config` WRITE;
/*!40000 ALTER TABLE `fruit_score_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `fruit_score_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fruit_type`
--

DROP TABLE IF EXISTS `fruit_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fruit_type` (
  `fruit_type_id` bigint NOT NULL AUTO_INCREMENT,
  `fruit_code` varchar(40) NOT NULL,
  `name` varchar(100) NOT NULL,
  `default_size_px` int NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`fruit_type_id`),
  UNIQUE KEY `uk_fruit_type_code` (`fruit_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fruit_type`
--

LOCK TABLES `fruit_type` WRITE;
/*!40000 ALTER TABLE `fruit_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `fruit_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game`
--

DROP TABLE IF EXISTS `game`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `game` (
  `game_id` bigint NOT NULL,
  `game_code` varchar(40) NOT NULL,
  `game_name` varchar(100) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`game_id`),
  UNIQUE KEY `uk_game_code` (`game_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game`
--

LOCK TABLES `game` WRITE;
/*!40000 ALTER TABLE `game` DISABLE KEYS */;
INSERT INTO `game` VALUES (7,'DOBBLE','그림 맞추기','2026-07-29 13:37:40.721873','2026-07-29 13:37:40.721873'),(8,'FRUIT_NINJA','과일 자르기','2026-07-29 13:37:40.721873','2026-07-29 13:37:40.721873'),(9,'RECYCLING','분리수거','2026-08-03 10:06:57.693847','2026-08-03 10:06:57.693847'),(10,'WORD_MATCH','낱말 맞추기','2026-08-03 10:06:57.810565','2026-08-03 10:06:57.810565');
/*!40000 ALTER TABLE `game` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_rule_version`
--

DROP TABLE IF EXISTS `game_rule_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_rule_version` (
  `rule_version_id` bigint NOT NULL AUTO_INCREMENT,
  `version_code` varchar(40) NOT NULL,
  `planned_duration_sec` int NOT NULL,
  `slice_speed_threshold` decimal(10,4) NOT NULL,
  `fruit_spawn_interval_ms` int NOT NULL,
  `max_visible_fruit` int NOT NULL,
  `active` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`rule_version_id`),
  UNIQUE KEY `uk_game_rule_version_code` (`version_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_rule_version`
--

LOCK TABLES `game_rule_version` WRITE;
/*!40000 ALTER TABLE `game_rule_version` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_rule_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_session`
--

DROP TABLE IF EXISTS `game_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_session` (
  `game_session_id` binary(16) NOT NULL,
  `child_id` bigint NOT NULL,
  `game_id` bigint NOT NULL,
  `client_play_id` binary(16) NOT NULL,
  `difficulty_code` varchar(30) DEFAULT NULL,
  `selected_at` datetime(6) NOT NULL,
  `play_started_at` datetime(6) NOT NULL,
  `completed_at` datetime(6) NOT NULL,
  `play_duration_seconds` int NOT NULL,
  `score` int NOT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`game_session_id`),
  UNIQUE KEY `uk_game_session_client_play_id` (`client_play_id`),
  KEY `fk_game_session_game` (`game_id`),
  CONSTRAINT `fk_game_session_game` FOREIGN KEY (`game_id`) REFERENCES `game` (`game_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_session`
--

LOCK TABLES `game_session` WRITE;
/*!40000 ALTER TABLE `game_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parent`
--

DROP TABLE IF EXISTS `parent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `parent` (
  `parent_id` bigint NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) DEFAULT NULL,
  `birth_date` date NOT NULL,
  `provider` varchar(20) NOT NULL,
  `provider_id` varchar(255) DEFAULT NULL,
  `role` varchar(20) NOT NULL DEFAULT 'PARENT',
  `pin_hash` varchar(255) DEFAULT NULL,
  `pin_failed_attempts` int NOT NULL DEFAULT '0',
  `pin_locked_until` datetime(6) DEFAULT NULL,
  `pin_set_at` datetime(6) DEFAULT NULL,
  `profile_image_key` varchar(512) NOT NULL DEFAULT 'profile-presets/parent-avatar',
  `profile_image_num` int NOT NULL DEFAULT '1',
  `deleted_at` datetime(6) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`parent_id`),
  UNIQUE KEY `uk_parent_email` (`email`),
  UNIQUE KEY `uk_parent_provider_id` (`provider_id`),
  CONSTRAINT `chk_parent_role` CHECK ((`role` in (_utf8mb4'PARENT',_utf8mb4'ADMIN')))
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parent`
--

LOCK TABLES `parent` WRITE;
/*!40000 ALTER TABLE `parent` DISABLE KEYS */;
/*!40000 ALTER TABLE `parent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recycling_game_result`
--

DROP TABLE IF EXISTS `recycling_game_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recycling_game_result` (
  `game_session_id` binary(16) NOT NULL,
  `rules_version` varchar(40) NOT NULL,
  `successful_count` int NOT NULL,
  `wrong_count` int NOT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`game_session_id`),
  CONSTRAINT `fk_recycling_result_game_session` FOREIGN KEY (`game_session_id`) REFERENCES `game_session` (`game_session_id`),
  CONSTRAINT `ck_recycling_result_successful_count` CHECK ((`successful_count` >= 0)),
  CONSTRAINT `ck_recycling_result_wrong_count` CHECK ((`wrong_count` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recycling_game_result`
--

LOCK TABLES `recycling_game_result` WRITE;
/*!40000 ALTER TABLE `recycling_game_result` DISABLE KEYS */;
/*!40000 ALTER TABLE `recycling_game_result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refresh_token`
--

DROP TABLE IF EXISTS `refresh_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `refresh_token` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `parent_id` bigint NOT NULL,
  `token_hash` varchar(64) NOT NULL,
  `expires_at` datetime(6) NOT NULL,
  `revoked` tinyint(1) NOT NULL DEFAULT '0',
  `remember_me` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_refresh_token_hash` (`token_hash`),
  KEY `fk_refresh_token_parent` (`parent_id`),
  CONSTRAINT `fk_refresh_token_parent` FOREIGN KEY (`parent_id`) REFERENCES `parent` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=383 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refresh_token`
--

LOCK TABLES `refresh_token` WRITE;
/*!40000 ALTER TABLE `refresh_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `refresh_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_conversation_summary`
--

DROP TABLE IF EXISTS `report_conversation_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_conversation_summary` (
  `report_conversation_summary_id` bigint NOT NULL AUTO_INCREMENT,
  `report_id` bigint NOT NULL,
  `source_conversation_ids` text NOT NULL,
  `diary_title` varchar(200) NOT NULL,
  `diary_content` text NOT NULL,
  `main_events` text NOT NULL,
  `emotions` text NOT NULL,
  `emotion_details` text NOT NULL,
  `interests` text NOT NULL,
  `notable_quotes` text NOT NULL,
  `conversation_guide` text NOT NULL,
  `model_version` varchar(100) DEFAULT NULL,
  `prompt_version` varchar(100) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`report_conversation_summary_id`),
  UNIQUE KEY `uk_report_conversation_summary_report` (`report_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_conversation_summary`
--

LOCK TABLES `report_conversation_summary` WRITE;
/*!40000 ALTER TABLE `report_conversation_summary` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_conversation_summary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_game_result`
--

DROP TABLE IF EXISTS `report_game_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_game_result` (
  `report_game_result_id` bigint NOT NULL AUTO_INCREMENT,
  `report_id` bigint NOT NULL,
  `game_session_id` binary(16) NOT NULL,
  `game_id` bigint NOT NULL,
  `game_code` varchar(40) NOT NULL,
  `game_name` varchar(100) NOT NULL,
  `completed_at` datetime(6) NOT NULL,
  `play_duration_seconds` int NOT NULL,
  `completed` tinyint(1) NOT NULL,
  `score` int NOT NULL,
  `result_metrics` text,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`report_game_result_id`),
  UNIQUE KEY `uk_report_game_result_report_session` (`report_id`,`game_session_id`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_game_result`
--

LOCK TABLES `report_game_result` WRITE;
/*!40000 ALTER TABLE `report_game_result` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_game_result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_generation_attempt`
--

DROP TABLE IF EXISTS `report_generation_attempt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_generation_attempt` (
  `attempt_id` bigint NOT NULL AUTO_INCREMENT,
  `report_id` bigint NOT NULL,
  `attempt_number` int NOT NULL,
  `attempt_status` varchar(20) NOT NULL,
  `started_at` datetime(6) NOT NULL,
  `ended_at` datetime(6) DEFAULT NULL,
  `failure_stage` varchar(40) DEFAULT NULL,
  `error_code` varchar(60) DEFAULT NULL,
  `failure_reason` varchar(1000) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`attempt_id`),
  UNIQUE KEY `uk_report_generation_attempt_number` (`report_id`,`attempt_number`),
  KEY `idx_report_generation_attempt_report` (`report_id`,`attempt_number`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_generation_attempt`
--

LOCK TABLES `report_generation_attempt` WRITE;
/*!40000 ALTER TABLE `report_generation_attempt` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_generation_attempt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_manual_regeneration`
--

DROP TABLE IF EXISTS `report_manual_regeneration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_manual_regeneration` (
  `regeneration_id` bigint NOT NULL AUTO_INCREMENT,
  `report_id` bigint NOT NULL,
  `child_id` bigint NOT NULL,
  `parent_id` bigint NOT NULL,
  `idempotency_key` varchar(100) NOT NULL,
  `regeneration_status` varchar(20) NOT NULL,
  `requested_at` datetime(6) NOT NULL,
  `previous_failure_reason` varchar(1000) DEFAULT NULL,
  `started_at` datetime(6) DEFAULT NULL,
  `ended_at` datetime(6) DEFAULT NULL,
  `failure_reason` varchar(1000) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`regeneration_id`),
  UNIQUE KEY `uk_report_manual_regeneration_parent_key` (`parent_id`,`idempotency_key`),
  KEY `idx_report_manual_regeneration_report` (`report_id`,`requested_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_manual_regeneration`
--

LOCK TABLES `report_manual_regeneration` WRITE;
/*!40000 ALTER TABLE `report_manual_regeneration` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_manual_regeneration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_notification`
--

DROP TABLE IF EXISTS `report_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_notification` (
  `notification_id` bigint NOT NULL AUTO_INCREMENT,
  `parent_id` bigint NOT NULL,
  `report_id` bigint NOT NULL,
  `child_id` bigint NOT NULL,
  `report_date` date NOT NULL,
  `notification_type` varchar(30) NOT NULL,
  `notification_status` varchar(20) NOT NULL,
  `message` varchar(200) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `scheduled_at` datetime(6) DEFAULT NULL,
  `delivered_at` datetime(6) DEFAULT NULL,
  `read_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`notification_id`),
  UNIQUE KEY `uk_report_notification_report_type` (`report_id`,`notification_type`),
  KEY `idx_report_notification_parent_created` (`parent_id`,`created_at`),
  KEY `idx_report_notification_report` (`report_id`),
  KEY `idx_report_notification_delivery` (`delivered_at`,`scheduled_at`),
  KEY `idx_report_notification_unread` (`parent_id`,`notification_status`,`scheduled_at`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_notification`
--

LOCK TABLES `report_notification` WRITE;
/*!40000 ALTER TABLE `report_notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_notification_failure`
--

DROP TABLE IF EXISTS `report_notification_failure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_notification_failure` (
  `notification_failure_id` bigint NOT NULL AUTO_INCREMENT,
  `report_id` bigint NOT NULL,
  `notification_type` varchar(30) NOT NULL,
  `failed_at` datetime(6) NOT NULL,
  `failure_reason` varchar(1000) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`notification_failure_id`),
  KEY `idx_report_notification_failure_report` (`report_id`,`failed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_notification_failure`
--

LOCK TABLES `report_notification_failure` WRITE;
/*!40000 ALTER TABLE `report_notification_failure` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_notification_failure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_notification_preference`
--

DROP TABLE IF EXISTS `report_notification_preference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_notification_preference` (
  `preference_id` bigint NOT NULL AUTO_INCREMENT,
  `parent_id` bigint NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `time_zone` varchar(50) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `notification_minute` smallint NOT NULL,
  PRIMARY KEY (`preference_id`),
  UNIQUE KEY `uk_report_notification_preference_parent` (`parent_id`),
  CONSTRAINT `chk_report_notification_minute` CHECK ((`notification_minute` between 0 and 1439))
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_notification_preference`
--

LOCK TABLES `report_notification_preference` WRITE;
/*!40000 ALTER TABLE `report_notification_preference` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_notification_preference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `word_match_problem_result`
--

DROP TABLE IF EXISTS `word_match_problem_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `word_match_problem_result` (
  `word_match_problem_result_id` bigint NOT NULL AUTO_INCREMENT,
  `game_session_id` binary(16) NOT NULL,
  `problem_code` varchar(40) NOT NULL,
  `question_order` int NOT NULL,
  `word_length` int NOT NULL,
  `status` varchar(20) NOT NULL,
  `wrong_count` int NOT NULL,
  `hint_used` tinyint(1) NOT NULL,
  `earned_score` int NOT NULL,
  `solve_time_ms` bigint DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`word_match_problem_result_id`),
  UNIQUE KEY `uk_word_match_result_order` (`game_session_id`,`question_order`),
  UNIQUE KEY `uk_word_match_result_problem` (`game_session_id`,`problem_code`),
  CONSTRAINT `fk_word_match_problem_result_session` FOREIGN KEY (`game_session_id`) REFERENCES `game_session` (`game_session_id`),
  CONSTRAINT `ck_word_match_problem_result_status` CHECK ((`status` in (_utf8mb4'COMPLETED',_utf8mb4'INCOMPLETE'))),
  CONSTRAINT `ck_word_match_problem_result_values` CHECK (((`question_order` >= 1) and (`word_length` between 2 and 4) and (`wrong_count` >= 0) and (`earned_score` >= 0) and ((`solve_time_ms` is null) or (`solve_time_ms` > 0))))
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `word_match_problem_result`
--

LOCK TABLES `word_match_problem_result` WRITE;
/*!40000 ALTER TABLE `word_match_problem_result` DISABLE KEYS */;
/*!40000 ALTER TABLE `word_match_problem_result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `word_match_result`
--

DROP TABLE IF EXISTS `word_match_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `word_match_result` (
  `game_session_id` binary(16) NOT NULL,
  `rules_version` varchar(40) NOT NULL,
  `solved_word_count` int NOT NULL,
  `incomplete_word_count` int NOT NULL,
  `wrong_count` int NOT NULL,
  `hint_used_count` int NOT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`game_session_id`),
  CONSTRAINT `fk_word_match_result_session` FOREIGN KEY (`game_session_id`) REFERENCES `game_session` (`game_session_id`),
  CONSTRAINT `ck_word_match_result_counts` CHECK (((`solved_word_count` >= 0) and (`incomplete_word_count` >= 0) and (`wrong_count` >= 0) and (`hint_used_count` >= 0)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `word_match_result`
--

LOCK TABLES `word_match_result` WRITE;
/*!40000 ALTER TABLE `word_match_result` DISABLE KEYS */;
/*!40000 ALTER TABLE `word_match_result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'a501'
--

--
-- Dumping routines for database 'a501'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-07 10:23:51
